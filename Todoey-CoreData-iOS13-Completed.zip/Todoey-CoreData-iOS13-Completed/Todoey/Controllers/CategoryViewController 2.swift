//
//  CategoryViewController 2.swift
//  Todoey
//
//  Created by Varun Ambulgekar on 07/12/24.
//  Copyright © 2024 Angela Yu. All rights reserved.
//


import UIKit
import CoreData

class CategoryViewController: UITableViewController {
    
    var categories = [Category]()
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    override func viewDidLoad() {
        super.viewDidLoad()
        loadCategories()
    }
    
    // MARK: - TableView Datasource Methods
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return categories.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CategoryCell", for: indexPath)
        cell.textLabel?.text = categories[indexPath.row].name
        return cell
    }
    
    // MARK: - TableView Delegate Methods
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let alert = UIAlertController(title: "Category Options", message: "Choose an action", preferredStyle: .actionSheet)
        
        let deleteAction = UIAlertAction(title: "Delete Category", style: .destructive) { [weak self] _ in
            self?.deleteCategory(at: indexPath)
        }
        
        let openAction = UIAlertAction(title: "Open Category", style: .default) { [weak self] _ in
            self?.performSegue(withIdentifier: "goToItems", sender: self)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        
        alert.addAction(openAction)
        alert.addAction(deleteAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goTo
